#ifndef eigen_H
#define eigen_H
#include "tools.h"
#include <math.h>
void obtain_max_eigenvalue(double *matrix, int *dimension_matrix, double *lambda, double **vector);
#endif