#ifndef qr_H
#define qr_H
#include <stdlib.h>
#include <math.h>
#include "tools.h"
void QR_decomposition(double *matrix, double **q_matrix, double **r_matrix, int *dimension);
#endif