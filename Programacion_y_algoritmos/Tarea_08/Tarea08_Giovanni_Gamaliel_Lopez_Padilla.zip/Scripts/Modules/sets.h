#ifndef sets_H
#define sets_H
#include "binary_tree.h"
node *obtain_set1();
node *obtain_set2();
node *obtain_set3();
#endif