#ifndef menu_H
#define menu_H
#include <stdio.h>
#include "functions.h"
void menu(hash_data *hast_table);
#endif